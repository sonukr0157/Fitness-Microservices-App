package com.fitness.userservice.model;

public enum UserRole {
    USER, ADMIN
}
